package com.suleman.jarvis.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.suleman.jarvis.MainActivity
import com.suleman.jarvis.R
import com.suleman.jarvis.audio.Speaker
import com.suleman.jarvis.audio.SpeechListener
import com.suleman.jarvis.brain.JarvisBrain
import com.suleman.jarvis.data.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Optional "always listening for the wake word" mode.
 *
 * Android only allows microphone use in the background through a FOREGROUND SERVICE that
 * shows a permanent notification. This service does exactly that, only starts after the
 * user gives consent in Settings, and only reacts to sentences containing "Jarvis".
 *
 * Android also blocks apps in the background from popping other apps open. So when a
 * command needs to open something (YouTube, Settings...), we show a notification
 * and you tap it.
 */
class JarvisService : Service() {

    companion object {
        const val ACTION_STOP = "com.suleman.jarvis.STOP_LISTENING"
        private const val CH_LISTEN = "jarvis_listening"
        private const val CH_ACTION = "jarvis_actions"
        private const val NOTIF_ID = 1001
        private val WAKE = listOf("jarvis", "जार्विस", "जारविस", "जर्विस", "जार्वीस", "जारवीस")

        val running = MutableStateFlow(false)

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, JarvisService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, JarvisService::class.java))
        }
    }

    private lateinit var settings: AppSettings
    private lateinit var speaker: Speaker
    private lateinit var brain: JarvisBrain
    private lateinit var listener: SpeechListener
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var alive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        speaker = Speaker(this, settings)
        brain = JarvisBrain(this, settings)
        listener = SpeechListener(this, object : SpeechListener.Callbacks {
            override fun onPartial(text: String) {}
            override fun onLevel(level: Float) {}
            override fun onFinal(text: String) {
                handleHeard(text)
            }

            override fun onError(message: String, quiet: Boolean) {
                listenAgain(if (quiet) 800L else 3000L)
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Microphone permission is needed.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        createChannels()
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Android did not allow background listening: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!alive) {
            alive = true
            running.value = true
            listenAgain(300)
        }
        return START_NOT_STICKY
    }

    private fun listenAgain(delayMs: Long) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (alive) listener.start(settings.recognitionTag)
        }, delayMs)
    }

    private fun handleHeard(text: String) {
        val lower = text.lowercase()
        if (WAKE.none { lower.contains(it) }) {
            listenAgain(300)
            return
        }
        scope.launch {
            val reply = brain.respond(text)
            reply.intent?.let { postActionNotification(reply.text, it) }
            speaker.speak(reply.text) { listenAgain(500) }
        }
    }

    private fun createChannels() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Background listening", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ACTION, "Jarvis actions", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("SULEMAN JARVIS AI is listening")
            .setContentText("Microphone is ON. Say \"Jarvis ...\" then your command.")
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(0, "STOP", stop)
            .build()
    }

    private fun postActionNotification(text: String, action: Intent) {
        action.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            this, (System.currentTimeMillis() % 100000).toInt(), action,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH_ACTION)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("Tap to continue")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        alive = false
        running.value = false
        handler.removeCallbacksAndMessages(null)
        listener.stop()
        speaker.shutdown()
        scope.cancel()
        super.onDestroy()
    }
}
