package com.suleman.jarvis.brain

import android.content.Context
import com.suleman.jarvis.data.AppSettings

/** Tries built-in commands first, then asks the AI service. Remembers the last few turns. */
class JarvisBrain(ctx: Context, private val settings: AppSettings) {
    private val commands = CommandProcessor(ctx.applicationContext, settings)
    private val history = ArrayDeque<Pair<String, String>>()

    suspend fun respond(userText: String): Reply {
        commands.handle(userText)?.let { return it }
        return try {
            val answer = AiClient.ask(settings, history.toList(), userText)
            history.addLast(userText to answer)
            while (history.size > 6) history.removeFirst()
            Reply(answer)
        } catch (e: AiException) {
            Reply(e.userMessage)
        } catch (e: Exception) {
            Reply(settings.t("Something went wrong. Please try again.", "कुछ गड़बड़ हो गई। फिर से कोशिश कीजिए।"))
        }
    }
}
