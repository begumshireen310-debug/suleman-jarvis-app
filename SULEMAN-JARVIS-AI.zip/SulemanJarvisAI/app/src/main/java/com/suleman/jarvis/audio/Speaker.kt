package com.suleman.jarvis.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.suleman.jarvis.data.AppSettings
import com.suleman.jarvis.net.ElevenLabs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * Speaks replies out loud.
 *  - Default: Android's built-in Text-to-Speech. This is a normal voice, NOT a clone.
 *  - Only if you created a voice with ElevenLabs AND turned it on: your cloned voice.
 *    If that fails, it falls back to the normal voice and tells you.
 */
class Speaker(private val ctx: Context, private val settings: AppSettings) {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null
    private var job: Job? = null

    var onNotice: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (!ttsReady) {
                main.post { onNotice?.invoke("No text-to-speech engine found. Install 'Speech Recognition & Synthesis' from Google.") }
            }
        }
    }

    fun speak(text: String, finished: () -> Unit = {}) {
        stop()
        val clean = text.take(3500)
        val wantsClone = settings.useClonedVoice && settings.voiceId.isNotBlank() && settings.elevenKey.isNotBlank()
        if (!wantsClone) {
            speakSystem(clean, finished)
            return
        }
        job = scope.launch {
            try {
                val audio = withContext(Dispatchers.IO) {
                    ElevenLabs.speak(settings.elevenKey, settings.voiceId, clean)
                }
                play(audio, finished)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onNotice?.invoke("Cloned voice failed (${e.message}). Using the phone's normal voice instead.")
                speakSystem(clean, finished)
            }
        }
    }

    private fun play(audio: ByteArray, finished: () -> Unit) {
        val f = File(ctx.cacheDir, "reply.mp3")
        f.writeBytes(audio)
        val p = MediaPlayer()
        player = p
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .build()
        )
        p.setDataSource(f.absolutePath)
        p.setOnCompletionListener {
            it.release()
            if (player === it) player = null
            finished()
        }
        p.setOnErrorListener { mp, _, _ ->
            mp.release()
            if (player === mp) player = null
            finished()
            true
        }
        p.prepare()
        p.start()
    }

    private fun speakSystem(text: String, finished: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) {
            finished()
            return
        }
        val loc = settings.ttsLocale
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            onNotice?.invoke(
                "${loc.displayLanguage} voice is not installed. Phone Settings > search 'Text-to-speech' > Google > Install voice data."
            )
            t.setLanguage(Locale.US)
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                main.post { finished() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { finished() }
            }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance")
    }

    fun stop() {
        job?.cancel()
        job = null
        tts?.stop()
        player?.let {
            try {
                it.release()
            } catch (e: Exception) {
            }
        }
        player = null
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        scope.cancel()
    }
}
