package com.suleman.jarvis.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun JarvisApp(vm: JarvisViewModel = viewModel()) {
    var screen by remember { mutableStateOf("main") }
    BackHandler(enabled = screen != "main") {
        screen = if (screen == "clone") "settings" else "main"
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(JBg1, JBg2)))
            .systemBarsPadding()
    ) {
        when (screen) {
            "settings" -> SettingsScreen(vm, onBack = { screen = "main" }, onClone = { screen = "clone" })
            "clone" -> CloneScreen(vm, onBack = { screen = "settings" })
            else -> MainScreen(vm, onSettings = { screen = "settings" })
        }
        vm.notice?.let { msg ->
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1B0D14))
                    .border(1.dp, JRed, RoundedCornerShape(14.dp))
                    .clickable { vm.notice = null }
                    .padding(14.dp)
            ) {
                Text(msg + "\n(tap to dismiss)", color = JText, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun MainScreen(vm: JarvisViewModel, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            vm.micTapped()
        } else {
            vm.notice = "Microphone permission denied. Phone Settings > Apps > SULEMAN JARVIS AI > Permissions > Microphone > Allow."
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(vm.chat.size) {
        if (vm.chat.isNotEmpty()) listState.animateScrollToItem(vm.chat.size - 1)
    }
    var input by remember { mutableStateOf("") }
    val en = vm.language == "english"

    val onMic = {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (vm.state == JState.IDLE && !granted) {
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            vm.micTapped()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(48.dp))
            Text(
                "SULEMAN JARVIS AI",
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                color = JBlue,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                letterSpacing = 3.sp,
                style = TextStyle(shadow = Shadow(JBlue, Offset.Zero, 24f))
            )
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = JBlue)
            }
        }

        JarvisOrb(vm.state, vm.level, Modifier.fillMaxWidth(0.62f).padding(vertical = 6.dp))

        val status = when (vm.state) {
            JState.IDLE -> if (en) "Tap the mic and speak" else "माइक दबाइए और बोलिए"
            JState.LISTENING -> if (vm.partial.isNotBlank()) vm.partial else if (en) "Listening..." else "सुन रहा हूँ..."
            JState.THINKING -> if (en) "Thinking..." else "सोच रहा हूँ..."
            JState.SPEAKING -> if (en) "Speaking... (tap to stop)" else "बोल रहा हूँ... (रोकने के लिए दबाइए)"
        }
        Text(
            status, color = if (vm.state == JState.LISTENING) JRed else JBlue,
            fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 4.dp)
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(vm.chat) { line -> ChatBubble(line) }
        }

        Spacer(Modifier.size(10.dp))
        MicButton(vm.state, onMic)
        Spacer(Modifier.size(10.dp))

        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text(if (en) "...or type a command" else "...या टाइप कीजिए", color = JMuted) }
            )
            Spacer(Modifier.size(8.dp))
            Button(onClick = {
                vm.sendText(input)
                input = ""
            }) { Text(if (en) "Send" else "भेजें") }
        }
    }
}

@Composable
fun ChatBubble(line: ChatLine) {
    val color = if (line.fromUser) JBlue else JRed
    Box(Modifier.fillMaxWidth(), contentAlignment = if (line.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Text(
            line.text,
            color = JText,
            fontSize = 15.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(color.copy(alpha = 0.10f))
                .border(1.dp, color.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun MicButton(state: JState, onClick: () -> Unit) {
    val color = if (state == JState.LISTENING) JRed else JBlue
    Box(
        Modifier
            .size(84.dp)
            .drawBehind {
                drawCircle(color.copy(alpha = 0.22f), radius = size.minDimension / 2 + 12.dp.toPx())
                drawCircle(color.copy(alpha = 0.12f), radius = size.minDimension / 2 + 24.dp.toPx())
            }
            .clip(CircleShape)
            .background(Color(0xFF08101C))
            .border(2.dp, color, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        MicGlyph(color, stop = state == JState.LISTENING || state == JState.SPEAKING)
    }
}
