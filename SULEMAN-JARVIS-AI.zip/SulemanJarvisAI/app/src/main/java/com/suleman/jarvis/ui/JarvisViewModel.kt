package com.suleman.jarvis.ui

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.suleman.jarvis.audio.Speaker
import com.suleman.jarvis.audio.SpeechListener
import com.suleman.jarvis.audio.VoiceRecorder
import com.suleman.jarvis.brain.JarvisBrain
import com.suleman.jarvis.data.AppSettings
import com.suleman.jarvis.net.ElevenLabs
import com.suleman.jarvis.service.JarvisService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class JState { IDLE, LISTENING, THINKING, SPEAKING }

data class ChatLine(val fromUser: Boolean, val text: String)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    val settings = AppSettings(app)
    private val brain = JarvisBrain(app, settings)
    private val speaker = Speaker(app, settings)
    private val recorder = VoiceRecorder(app)

    // ---- main screen state ----
    var state by mutableStateOf(JState.IDLE)
        private set
    var partial by mutableStateOf("")
        private set
    var level by mutableStateOf(0f)
        private set
    var notice by mutableStateOf<String?>(null)
    val chat = mutableStateListOf<ChatLine>()

    // ---- settings state (mirrors of stored values so Compose updates) ----
    var language by mutableStateOf(settings.language)
        private set
    var provider by mutableStateOf(settings.provider)
        private set
    var useClone by mutableStateOf(settings.useClonedVoice)
        private set
    var voiceId by mutableStateOf(settings.voiceId)
        private set
    var cloneConsent by mutableStateOf(settings.cloneConsent)
        private set
    var hasGemini by mutableStateOf(settings.geminiKey.isNotBlank())
        private set
    var hasClaude by mutableStateOf(settings.claudeKey.isNotBlank())
        private set
    var hasEleven by mutableStateOf(settings.elevenKey.isNotBlank())
        private set

    // ---- voice cloning state ----
    var recording by mutableStateOf(false)
        private set
    var recSeconds by mutableIntStateOf(0)
        private set
    var hasSample by mutableStateOf(recorder.file.exists() && recorder.file.length() > 0)
        private set
    var voiceBusy by mutableStateOf(false)
        private set
    var voiceStatus by mutableStateOf("")
        private set
    private var timer: Job? = null

    val voiceLabel: String
        get() = if (useClone && voiceId.isNotBlank())
            "ElevenLabs CLONED voice" else "Phone text-to-speech (NOT cloned)"

    private val listener = SpeechListener(app, object : SpeechListener.Callbacks {
        override fun onPartial(text: String) {
            partial = text
        }

        override fun onLevel(level: Float) {
            this@JarvisViewModel.level = level
        }

        override fun onFinal(text: String) {
            level = 0f
            partial = ""
            if (text.isBlank()) state = JState.IDLE else process(text)
        }

        override fun onError(message: String, quiet: Boolean) {
            level = 0f
            partial = ""
            state = JState.IDLE
            notice = if (quiet) settings.t("I didn't catch that. Please try again.", "सुनाई नहीं दिया। फिर से बोलिए।") else message
        }
    })

    init {
        speaker.onNotice = { notice = it }
    }

    // ================= talking =================

    fun micTapped() {
        when (state) {
            JState.LISTENING -> listener.finish()
            JState.SPEAKING -> {
                speaker.stop()
                state = JState.IDLE
            }
            JState.THINKING -> {}
            JState.IDLE -> startListening()
        }
    }

    private fun startListening() {
        if (JarvisService.running.value) {
            notice = "Background listening is ON, so the microphone is in use. Turn it off in Settings to use the mic button."
            return
        }
        if (recording) return
        speaker.stop()
        partial = ""
        state = JState.LISTENING
        listener.start(settings.recognitionTag)
    }

    fun sendText(text: String) {
        if (text.isBlank() || state != JState.IDLE) return
        process(text.trim())
    }

    private fun process(text: String) {
        chat.add(ChatLine(true, text))
        state = JState.THINKING
        viewModelScope.launch {
            val reply = brain.respond(text)
            chat.add(ChatLine(false, reply.text))
            state = JState.SPEAKING
            speaker.speak(reply.text) {
                if (state == JState.SPEAKING) state = JState.IDLE
            }
            reply.intent?.let { launchIntent(it) }
        }
    }

    private fun launchIntent(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(i)
        } catch (e: Exception) {
            notice = "Could not open that."
        }
    }

    // ================= settings =================

    fun changeLanguage(v: String) {
        settings.language = v
        language = v
    }

    fun changeProvider(v: String) {
        settings.provider = v
        provider = v
    }

    fun saveKey(kind: String, value: String) {
        when (kind) {
            "gemini" -> { settings.geminiKey = value; hasGemini = value.isNotBlank() }
            "claude" -> { settings.claudeKey = value; hasClaude = value.isNotBlank() }
            "eleven" -> { settings.elevenKey = value; hasEleven = value.isNotBlank() }
        }
    }

    fun setUseClone(v: Boolean) {
        settings.useClonedVoice = v
        useClone = v
    }

    fun setCloneConsent(v: Boolean) {
        settings.cloneConsent = v
        cloneConsent = v
    }

    // ================= voice cloning =================

    fun startRecording() {
        if (!cloneConsent) {
            notice = "Please tick the consent box first."
            return
        }
        if (JarvisService.running.value || state == JState.LISTENING) {
            notice = "The microphone is busy. Turn off background listening / stop the mic first."
            return
        }
        try {
            speaker.stop()
            recorder.start()
            recording = true
            recSeconds = 0
            voiceStatus = ""
            timer = viewModelScope.launch {
                while (true) {
                    delay(1000)
                    recSeconds++
                    if (recSeconds >= 180) {
                        stopRecording()
                        break
                    }
                }
            }
        } catch (e: Exception) {
            recording = false
            notice = "Could not start recording: ${e.message}"
        }
    }

    fun stopRecording() {
        timer?.cancel()
        recording = false
        val ok = recorder.stop()
        hasSample = ok && recorder.file.exists() && recorder.file.length() > 0
        voiceStatus = when {
            !ok -> "Recording was too short. Please try again."
            recSeconds < 60 -> "Only ${recSeconds}s recorded. About 2 minutes gives a better voice."
            else -> "Saved ${recSeconds}s sample on this phone."
        }
    }

    fun uploadVoice() {
        val key = settings.elevenKey
        if (!cloneConsent) {
            notice = "Please tick the consent box first."
            return
        }
        if (key.isBlank()) {
            notice = "Add your ElevenLabs API key in Settings first."
            return
        }
        if (!hasSample) {
            notice = "Record your voice first."
            return
        }
        viewModelScope.launch {
            voiceBusy = true
            voiceStatus = "Uploading... this can take up to a minute."
            try {
                val id = withContext(Dispatchers.IO) {
                    ElevenLabs.createVoice(key, "Suleman JARVIS voice", recorder.file)
                }
                settings.voiceId = id
                voiceId = id
                setUseClone(true)
                voiceStatus = "Done! Your cloned voice is ready and switched on."
            } catch (e: Exception) {
                voiceStatus = e.message ?: "Upload failed."
            } finally {
                voiceBusy = false
            }
        }
    }

    fun testVoice() {
        speaker.speak(
            settings.t(
                "Hello, this is a voice test.",
                "नमस्ते, मैं आपका जार्विस हूँ। यह आवाज़ का टेस्ट है।"
            )
        )
    }

    fun deleteVoice() {
        val id = voiceId
        val key = settings.elevenKey
        viewModelScope.launch {
            voiceBusy = true
            try {
                if (id.isNotBlank() && key.isNotBlank()) {
                    withContext(Dispatchers.IO) { ElevenLabs.deleteVoice(key, id) }
                }
                voiceStatus = "Cloned voice deleted."
            } catch (e: Exception) {
                voiceStatus = "Removed from the app, but could not delete online (${e.message}). Delete it in your ElevenLabs dashboard."
            } finally {
                settings.voiceId = ""
                voiceId = ""
                setUseClone(false)
                recorder.file.delete()
                hasSample = false
                voiceBusy = false
            }
        }
    }

    override fun onCleared() {
        timer?.cancel()
        if (recording) recorder.stop()
        listener.stop()
        speaker.shutdown()
        super.onCleared()
    }
}
