package com.suleman.jarvis.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.suleman.jarvis.service.JarvisService

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(JPanel)
            .border(1.dp, JBlue.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = JBlue, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 1.sp)
        content()
    }
}

@Composable
private fun RadioRow(selected: Boolean, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.size(10.dp))
        Text(label, color = JText, fontSize = 15.sp)
    }
}

@Composable
private fun Note(text: String, color: Color = JMuted) {
    Text(text, color = color, fontSize = 12.5.sp, lineHeight = 17.sp)
}

@Composable
private fun KeyField(label: String, saved: Boolean, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text(label) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { onSave(text); text = "" }, enabled = text.isNotBlank()) { Text("Save") }
            Spacer(Modifier.size(10.dp))
            Text(
                if (saved) "✓ saved (encrypted)" else "not set",
                color = if (saved) JBlue else JMuted, fontSize = 13.sp
            )
            if (saved) {
                Spacer(Modifier.size(6.dp))
                TextButton(onClick = { onSave("") }) { Text("Remove", color = JRed) }
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("← Back", color = JBlue, fontSize = 15.sp) }
        Spacer(Modifier.size(8.dp))
        Text(title, color = JText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
fun SettingsScreen(vm: JarvisViewModel, onBack: () -> Unit, onClone: () -> Unit) {
    val ctx = LocalContext.current
    val running by JarvisService.running.collectAsState()
    var showConsent by remember { mutableStateOf(false) }

    val permsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notif = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (mic && notif) {
            vm.settings.bgConsent = true
            JarvisService.start(ctx)
        } else {
            vm.notice = "Background listening needs BOTH Microphone and Notification permission (the notification is how Android shows that the mic is on)."
        }
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
        ScreenHeader("Settings", onBack)

        Section("LANGUAGE / भाषा") {
            RadioRow(vm.language == "hindi", "हिन्दी (Hindi)") { vm.changeLanguage("hindi") }
            RadioRow(vm.language == "hinglish", "Hinglish (Hindi + English mix)") { vm.changeLanguage("hinglish") }
            RadioRow(vm.language == "english", "English") { vm.changeLanguage("english") }
            Note("Hindi and Hinglish use the Hindi speech recogniser, so you can mix English words. Replies in Hindi/Hinglish are spoken in Hindi.")
        }

        Section("AI BRAIN") {
            RadioRow(vm.provider == "gemini", "Google Gemini (free tier available)") { vm.changeProvider("gemini") }
            RadioRow(vm.provider == "claude", "Anthropic Claude (paid, pay-per-use)") { vm.changeProvider("claude") }
            KeyField("Gemini API key", vm.hasGemini) { vm.saveKey("gemini", it) }
            KeyField("Anthropic API key", vm.hasClaude) { vm.saveKey("claude", it) }
            Note("Opening apps, time, date and searches work WITHOUT any key. Keys are only for general questions and chat. Keys are stored encrypted with the Android Keystore and are only sent to the service you chose.")
        }

        Section("VOICE") {
            Text("Current voice: ${vm.voiceLabel}", color = JText, fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = vm.useClone && vm.voiceId.isNotBlank(),
                    onCheckedChange = { vm.updateUseClone(it) },
                    enabled = vm.voiceId.isNotBlank()
                )
                Spacer(Modifier.size(10.dp))
                Text("Speak in my cloned voice", color = JText, fontSize = 15.sp)
            }
            KeyField("ElevenLabs API key (only for voice cloning)", vm.hasEleven) { vm.saveKey("eleven", it) }
            Button(onClick = onClone) { Text("Record & clone my voice") }
            Note("By default the app uses your phone's normal text-to-speech. That is NOT a clone. A clone only exists after you record your voice and upload it to ElevenLabs (a separate, paid service).")
        }

        Section("BACKGROUND LISTENING") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = running, onCheckedChange = { on ->
                    if (on) {
                        showConsent = true
                    } else {
                        JarvisService.stop(ctx)
                    }
                })
                Spacer(Modifier.size(10.dp))
                Text("Listen for \"Jarvis\" in background", color = JText, fontSize = 15.sp)
            }
            Note("Android does not let normal apps use the microphone secretly in the background. This option uses an official foreground service: a permanent notification is shown while the microphone is on, and you can stop it any time from the notification or from here. It does not start by itself after a phone restart.")
        }

        Section("ABOUT") {
            Note("SULEMAN JARVIS AI 1.0 · Android 8.0+ (built for Android 15/16, OPPO F29). Voice recognition is done by your phone's Google speech service.")
        }
        Spacer(Modifier.size(24.dp))
    }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Allow background listening?") },
            text = {
                Text(
                    "• The microphone will stay ON while this is enabled.\n" +
                        "• A notification will always be visible while it listens.\n" +
                        "• The app only reacts to sentences that contain \"Jarvis\". Speech is processed by your phone's speech service (Google) and, for general questions, the text you say is sent to the AI service you chose.\n" +
                        "• Battery use will be higher.\n" +
                        "• You can stop it any time."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showConsent = false
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    permsLauncher.launch(perms.toTypedArray())
                }) { Text("I agree, start", color = JBlue) }
            },
            dismissButton = { TextButton(onClick = { showConsent = false }) { Text("Cancel") } }
        )
    }
}

private const val READ_TEXT =
    "Namaste, mera naam Suleman hai. Aaj main apni awaaz record kar raha hoon taaki mera AI assistant " +
        "mere jaisi awaaz mein baat kar sake. Hello, this is my natural voice. I like technology, gaming and " +
        "learning new things every day. Mausam aaj kaafi accha hai, aur main apne doston ke saath cricket " +
        "dekhne ja raha hoon. Please remember this is a clear, calm sample of my own voice. " +
        "Ab main kuch aur baatein karta hoon: kal subah mujhe jaldi uthna hai, phir chai peeni hai, aur uske baad " +
        "kaam shuru karna hai. (Keep talking naturally until the timer reaches about 2 minutes.)"

@Composable
fun CloneScreen(vm: JarvisViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            vm.startRecording()
        } else {
            vm.notice = "Microphone permission is needed to record."
        }
    }
    val mm = vm.recSeconds / 60
    val ss = vm.recSeconds % 60

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
        ScreenHeader("Clone my voice", onBack)

        Section("HONEST NOTE") {
            Note(
                "Voice cloning is done by ElevenLabs, a separate paid service (Instant Voice Cloning needs a paid plan and an API key). " +
                    "Your recording is uploaded to them. If you skip this, the app keeps using the phone's normal voice, which is not a clone.",
                JText
            )
        }

        Section("1 · CONSENT") {
            Row(Modifier.clickable { vm.updateCloneConsent(!vm.cloneConsent) }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = vm.cloneConsent, onCheckedChange = { vm.updateCloneConsent(it) })
                Text(
                    "This is MY OWN voice. I agree to upload my recording to ElevenLabs to create a voice model.",
                    color = JText, fontSize = 14.sp
                )
            }
        }

        Section("2 · RECORD (about 2 minutes)") {
            Note("Find a quiet room, hold the phone about a hand's width from your mouth, and read this or just talk naturally:")
            Text(READ_TEXT, color = JText, fontSize = 14.sp, lineHeight = 20.sp)
            Text(
                "%d:%02d / 2:00".format(mm, ss),
                color = if (vm.recording) JRed else JBlue, fontSize = 26.sp, fontWeight = FontWeight.Bold
            )
            if (!vm.recording) {
                Button(onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        vm.startRecording()
                    } else {
                        permLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }) { Text(if (vm.hasSample) "Record again" else "Start recording") }
            } else {
                Button(
                    onClick = { vm.stopRecording() },
                    colors = ButtonDefaults.buttonColors(containerColor = JRed)
                ) { Text("Stop recording") }
            }
        }

        Section("3 · UPLOAD & CREATE VOICE") {
            Button(onClick = { vm.uploadVoice() }, enabled = vm.hasSample && !vm.recording && !vm.voiceBusy) {
                Text(if (vm.voiceBusy) "Please wait..." else "Upload & create my voice")
            }
            Button(onClick = { vm.testVoice() }, enabled = !vm.voiceBusy) { Text("Test current voice") }
            Text("Current voice: ${vm.voiceLabel}", color = JText, fontSize = 14.sp)
            if (vm.voiceStatus.isNotBlank()) Text(vm.voiceStatus, color = JBlue, fontSize = 14.sp)
            if (vm.voiceId.isNotBlank()) {
                TextButton(onClick = { vm.deleteVoice() }, enabled = !vm.voiceBusy) {
                    Text("Delete my cloned voice", color = JRed)
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}
