package com.suleman.jarvis.brain

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.suleman.jarvis.data.AppSettings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reply(val text: String, val intent: Intent? = null)

/**
 * Handles the built-in phone commands locally (no internet, no API key needed).
 * Returns null when the sentence is not a command, so it can go to the AI instead.
 * Works with Hindi (Devanagari), Hinglish (Roman letters) and English.
 */
class CommandProcessor(private val ctx: Context, private val s: AppSettings) {

    private val wake = setOf(
        "jarvis", "जार्विस", "जारविस", "जर्विस", "जार्वीस", "जारवीस", "hey", "हे", "ok", "okay", "ओके"
    )
    private val openWords = setOf(
        "open", "launch", "start", "kholo", "khol", "kholna", "खोलो", "खोल", "खोलिए", "चालू", "शुरू", "चलाओ", "chalu", "shuru"
    )
    private val appFiller = setOf(
        "app", "application", "एप", "ऐप", "एप्प", "को", "please", "करो", "karo", "do", "दो", "de", "the",
        "my", "मेरा", "मेरे", "जी", "ji", "kar", "कर", "kardo", "कीजिए"
    )
    private val searchFiller = setOf(
        "search", "google", "serach", "सर्च", "खोजो", "ढूंढो", "ढूँढो", "dhundo", "khojo", "find", "look", "up",
        "karo", "करो", "kar", "कर", "on", "for", "about", "please", "पर", "par", "pe", "पे", "में", "mein",
        "के", "ke", "लिए", "liye", "बारे", "baare", "bare", "गूगल", "gugal"
    )
    private val ytFiller = setOf(
        "youtube", "यूट्यूब", "यूटयूब", "play", "चलाओ", "बजाओ", "chalao", "bajao", "search", "सर्च", "dhundo",
        "ढूंढो", "ढूँढो", "on", "पर", "par", "pe", "पे", "में", "mein", "for", "के", "ke", "लिए", "liye",
        "please", "karo", "करो", "kar", "कर", "open", "खोलो", "kholo"
    )
    private val aliases = mapOf(
        "वॉट्सऐप" to "whatsapp", "वॉट्सएप" to "whatsapp", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "कैमरा" to "camera", "क्रोम" to "chrome", "गैलरी" to "gallery", "इंस्टाग्राम" to "instagram",
        "फेसबुक" to "facebook", "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "मैप्स" to "maps",
        "जीमेल" to "gmail", "फोन" to "phone", "मैसेज" to "messages", "टेलीग्राम" to "telegram",
        "स्पॉटिफाई" to "spotify", "नेटफ्लिक्स" to "netflix", "प्लेस्टोर" to "play store"
    )

    private fun has(t: String, vararg keys: String) = keys.any { t.contains(it) }

    fun handle(raw: String): Reply? {
        val tokens = raw.lowercase(Locale.ROOT).split(Regex("\\s+"))
            .map { it.trim('.', ',', '!', '?', '।', '"', '\'') }
            .filter { it.isNotBlank() && it !in wake }
        if (tokens.isEmpty()) return Reply(s.t("Yes, I'm listening.", "जी, बोलिए।"))
        val t = tokens.joinToString(" ")
            .replace("you tube", "youtube").replace("यू ट्यूब", "यूट्यूब")
        val opening = tokens.any { it in openWords }

        // ---- time ----
        if (has(t, "what time", "current time", "time now", "the time", "time kya", "kitne baje", "time batao",
                "samay batao", "कितने बजे", "टाइम क्या", "टाइम बताओ", "समय क्या", "समय बताओ", "क्या टाइम")) {
            val time = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
            return Reply(s.t("It's $time.", "अभी समय है $time।"))
        }

        // ---- date ----
        if (Regex("\\bdate\\b").containsMatchIn(t) || has(t, "what day", "tarikh", "तारीख", "आज कौन सा दिन", "aaj kya din")) {
            val loc = if (s.hindi) Locale.forLanguageTag("hi-IN") else Locale.ENGLISH
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", loc).format(Date())
            return Reply(s.t("Today is $d.", "आज $d है।"))
        }

        // ---- YouTube ----
        if (has(t, "youtube", "यूट्यूब", "यूटयूब")) {
            val wantsSearch = has(t, "search", "play", "सर्च", "चलाओ", "बजाओ", "chalao", "bajao", "dhundo", "ढूंढो", "ढूँढो")
            val q = tokens.filter { it !in ytFiller && it != "you" && it != "tube" && it != "यू" && it != "ट्यूब" }
                .joinToString(" ")
            return if (wantsSearch && q.isNotBlank()) {
                Reply(
                    s.t("Searching YouTube for $q.", "YouTube पर $q खोज रहा हूँ।"),
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                )
            } else {
                val launch = ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                Reply(s.t("Opening YouTube.", "YouTube खोल रहा हूँ।"), launch)
            }
        }

        // ---- Settings ----
        if (opening && has(t, "settings", "setting", "सेटिंग")) {
            return Reply(s.t("Opening Settings.", "सेटिंग्स खोल रहा हूँ।"), Intent(Settings.ACTION_SETTINGS))
        }

        // ---- Web search ----
        if (has(t, "search", "google", "सर्च", "खोजो", "ढूंढो", "ढूँढो", "dhundo", "khojo")) {
            val q = tokens.filter { it !in searchFiller }.joinToString(" ")
            return if (q.isBlank()) {
                Reply(s.t("What should I search for?", "क्या खोजना है?"))
            } else {
                Reply(
                    s.t("Searching the web for $q.", "$q वेब पर खोज रहा हूँ।"),
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                )
            }
        }

        // ---- Launch any installed app ----
        if (opening) {
            val nameRaw = tokens.filter { it !in openWords && it !in appFiller }.joinToString(" ")
            if (nameRaw.isBlank()) return Reply(s.t("Which app should I open?", "कौन सा ऐप खोलूँ?"))
            val name = aliases[nameRaw] ?: nameRaw.split(" ").joinToString(" ") { aliases[it] ?: it }
            val found = findApp(name)
            return if (found != null) {
                Reply(s.t("Opening ${found.second}.", "${found.second} खोल रहा हूँ।"), found.first)
            } else {
                Reply(
                    s.t("I couldn't find an app named $nameRaw.", "$nameRaw नाम का ऐप नहीं मिला।")
                )
            }
        }
        return null
    }

    /** Returns the launch intent and the app's display name. */
    private fun findApp(name: String): Pair<Intent, String>? {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(main, 0)
        val n = name.lowercase(Locale.ROOT).trim()
        if (n.isEmpty()) return null
        val labeled = apps.map { it to it.loadLabel(pm).toString() }
        val hit = labeled.firstOrNull { it.second.lowercase(Locale.ROOT) == n }
            ?: labeled.firstOrNull { it.second.lowercase(Locale.ROOT).contains(n) }
            ?: labeled.firstOrNull { it.second.length > 3 && n.contains(it.second.lowercase(Locale.ROOT)) }
            ?: return null
        val intent = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return null
        return intent to hit.second
    }
}
