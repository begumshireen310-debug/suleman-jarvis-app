package com.suleman.jarvis.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Wraps Android's built-in SpeechRecognizer. Must be used from the main thread. */
class SpeechListener(private val ctx: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun onPartial(text: String)
        fun onFinal(text: String)
        /** quiet = nothing important (e.g. you said nothing); no need to show a message. */
        fun onError(message: String, quiet: Boolean)
        fun onLevel(level: Float)
    }

    private var rec: SpeechRecognizer? = null

    val available: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun start(languageTag: String) {
        stop()
        if (!available) {
            cb.onError("Speech recognition is not available. Install or update the 'Google' app.", false)
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                cb.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (t.isNotBlank()) cb.onPartial(t)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                cb.onFinal(t)
            }

            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                    SpeechRecognizer.ERROR_CLIENT -> cb.onError("", true)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        cb.onError("Microphone permission is missing.", false)
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        cb.onError("Speech recognition needs internet (or the offline language pack).", false)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                        cb.onError("Speech recognizer is busy. Try again in a moment.", false)
                    SpeechRecognizer.ERROR_AUDIO ->
                        cb.onError("Could not use the microphone. Is another app using it?", false)
                    else -> cb.onError("Speech recognition error ($error).", false)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(i)
    }

    /** Stop recording and process what was said so far. */
    fun finish() {
        rec?.stopListening()
    }

    /** Cancel and release. */
    fun stop() {
        rec?.let {
            try {
                it.cancel()
                it.destroy()
            } catch (e: Exception) {
            }
        }
        rec = null
    }
}
