package com.suleman.jarvis.net

import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class VoiceException(message: String) : Exception(message)

/**
 * ElevenLabs is a real, separate paid service. "Instant Voice Cloning" needs a paid plan
 * (see README). This is the ONLY place in the app where a cloned voice is made.
 */
object ElevenLabs {
    private const val BASE = "https://api.elevenlabs.io/v1"

    /** Uploads your recording and returns the new voice_id. Blocking: call from a background thread. */
    fun createVoice(apiKey: String, name: String, sample: File): String {
        val boundary = "----jarvis" + System.currentTimeMillis()
        val conn = URL("$BASE/voices/add").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 20000
            conn.readTimeout = 180000
            conn.setChunkedStreamingMode(0)
            conn.setRequestProperty("xi-api-key", apiKey)
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            DataOutputStream(conn.outputStream).use { out ->
                fun w(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
                w("--$boundary\r\nContent-Disposition: form-data; name=\"name\"\r\n\r\n$name\r\n")
                w("--$boundary\r\nContent-Disposition: form-data; name=\"files\"; filename=\"${sample.name}\"\r\nContent-Type: audio/mp4\r\n\r\n")
                sample.inputStream().use { it.copyTo(out) }
                w("\r\n--$boundary--\r\n")
            }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw VoiceException(explain(code, text))
            return JSONObject(text).getString("voice_id")
        } catch (e: IOException) {
            throw VoiceException("No internet connection.")
        } finally {
            conn.disconnect()
        }
    }

    /** Speaks [text] in the cloned voice. Returns MP3 bytes. Blocking. */
    fun speak(apiKey: String, voiceId: String, text: String): ByteArray {
        val conn = URL("$BASE/text-to-speech/$voiceId?output_format=mp3_44100_128")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.setRequestProperty("xi-api-key", apiKey)
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw VoiceException(explain(code, err))
            }
            return conn.inputStream.use { it.readBytes() }
        } catch (e: IOException) {
            throw VoiceException("No internet connection.")
        } finally {
            conn.disconnect()
        }
    }

    fun deleteVoice(apiKey: String, voiceId: String) {
        val conn = URL("$BASE/voices/$voiceId").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "DELETE"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("xi-api-key", apiKey)
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw VoiceException(explain(code, err))
            }
        } catch (e: IOException) {
            throw VoiceException("No internet connection.")
        } finally {
            conn.disconnect()
        }
    }

    private fun explain(code: Int, body: String): String {
        val detail = try {
            val d = JSONObject(body).opt("detail")
            when (d) {
                is JSONObject -> d.optString("message")
                is String -> d
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
        val base = when (code) {
            401 -> "ElevenLabs API key was rejected."
            402, 403 -> "Your ElevenLabs plan does not allow this (voice cloning needs a paid plan)."
            422 -> "ElevenLabs could not use this audio."
            429 -> "ElevenLabs limit reached. Try later."
            else -> "ElevenLabs error ($code)."
        }
        return if (detail.isNotBlank()) "$base $detail" else base
    }
}
