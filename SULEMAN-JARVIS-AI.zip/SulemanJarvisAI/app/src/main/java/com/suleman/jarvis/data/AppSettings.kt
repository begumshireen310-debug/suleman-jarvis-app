package com.suleman.jarvis.data

import android.content.Context
import java.util.Locale

class AppSettings(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    /** "hindi", "hinglish" or "english" */
    var language: String
        get() = sp.getString("language", "hinglish") ?: "hinglish"
        set(v) { sp.edit().putString("language", v).apply() }

    /** "gemini" or "claude" */
    var provider: String
        get() = sp.getString("provider", "gemini") ?: "gemini"
        set(v) { sp.edit().putString("provider", v).apply() }

    var useClonedVoice: Boolean
        get() = sp.getBoolean("use_clone", false)
        set(v) { sp.edit().putBoolean("use_clone", v).apply() }

    var voiceId: String
        get() = sp.getString("voice_id", "") ?: ""
        set(v) { sp.edit().putString("voice_id", v).apply() }

    var cloneConsent: Boolean
        get() = sp.getBoolean("clone_consent", false)
        set(v) { sp.edit().putBoolean("clone_consent", v).apply() }

    var bgConsent: Boolean
        get() = sp.getBoolean("bg_consent", false)
        set(v) { sp.edit().putBoolean("bg_consent", v).apply() }

    var geminiKey: String
        get() = SecureStore.get(ctx, "gemini_key")
        set(v) { SecureStore.put(ctx, "gemini_key", v) }

    var claudeKey: String
        get() = SecureStore.get(ctx, "claude_key")
        set(v) { SecureStore.put(ctx, "claude_key", v) }

    var elevenKey: String
        get() = SecureStore.get(ctx, "eleven_key")
        set(v) { SecureStore.put(ctx, "eleven_key", v) }

    /** Hindi and Hinglish both use the Hindi recognizer; English uses Indian English. */
    val recognitionTag: String
        get() = if (language == "english") "en-IN" else "hi-IN"

    val ttsLocale: Locale
        get() = Locale.forLanguageTag(if (language == "english") "en-IN" else "hi-IN")

    val hindi: Boolean
        get() = language != "english"

    /** Pick the English or Hindi version of a message. */
    fun t(en: String, hi: String): String = if (hindi) hi else en
}
