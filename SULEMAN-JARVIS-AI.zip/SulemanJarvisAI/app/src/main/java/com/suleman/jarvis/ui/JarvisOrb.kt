package com.suleman.jarvis.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** The animated Iron-Man style AI circle. Colour and pulse change with the assistant's state. */
@Composable
fun JarvisOrb(state: JState, level: Float, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "orb")
    val rot1 by inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "r1"
    )
    val rot2 by inf.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "r2"
    )
    val rot3 by inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5500, easing = LinearEasing)), label = "r3"
    )
    val pulse by inf.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val lvl by animateFloatAsState(level.coerceIn(0f, 1f), label = "level")
    val core = when (state) {
        JState.IDLE -> JBlue
        JState.LISTENING -> JRed
        JState.THINKING -> JAmber
        JState.SPEAKING -> Color(0xFF7FDBFF)
    }
    val speed = if (state == JState.THINKING) 2f else 1f

    Canvas(modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2f

        drawCircle(
            brush = Brush.radialGradient(listOf(core.copy(alpha = 0.35f), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )

        fun ring(radius: Float, start: Float, sweep: Float, count: Int, color: Color, width: Float) {
            val tl = Offset(c.x - radius, c.y - radius)
            val sz = Size(radius * 2, radius * 2)
            repeat(count) { i ->
                // soft glow underneath
                drawArc(
                    color = color.copy(alpha = 0.18f), startAngle = start + i * 360f / count, sweepAngle = sweep,
                    useCenter = false, topLeft = tl, size = sz,
                    style = Stroke(width * 3.2f, cap = StrokeCap.Round)
                )
                drawArc(
                    color = color, startAngle = start + i * 360f / count, sweepAngle = sweep,
                    useCenter = false, topLeft = tl, size = sz,
                    style = Stroke(width, cap = StrokeCap.Round)
                )
            }
        }

        ring(r * 0.95f, rot1 * speed, 50f, 4, JBlue, 3.dp.toPx())
        ring(r * 0.80f, rot2 * speed, 28f, 6, JRed, 2.5.dp.toPx())
        ring(r * 0.65f, rot3 * speed, 80f, 3, JBlue.copy(alpha = 0.8f), 2.dp.toPx())

        val coreR = r * 0.38f * pulse * (1f + lvl * 0.35f)
        drawCircle(core.copy(alpha = 0.9f), radius = r * 0.5f * pulse, center = c, style = Stroke(1.5.dp.toPx()))
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White, core, Color.Transparent), center = c, radius = coreR * 1.3f),
            radius = coreR * 1.3f, center = c
        )
    }
}

/** Hand-drawn microphone (or stop square) so we don't need an icon library. */
@Composable
fun MicGlyph(color: Color, stop: Boolean, modifier: Modifier = Modifier.size(34.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (stop) {
            drawRoundRect(
                color = color, topLeft = Offset(w * 0.25f, h * 0.25f),
                size = Size(w * 0.5f, h * 0.5f), cornerRadius = CornerRadius(6f, 6f)
            )
        } else {
            drawRoundRect(
                color = color, topLeft = Offset(w * 0.36f, h * 0.04f),
                size = Size(w * 0.28f, h * 0.55f), cornerRadius = CornerRadius(w * 0.14f, w * 0.14f)
            )
            drawArc(
                color = color, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                topLeft = Offset(w * 0.2f, h * 0.22f), size = Size(w * 0.6f, h * 0.5f),
                style = Stroke(w * 0.07f, cap = StrokeCap.Round)
            )
            drawLine(
                color = color, start = Offset(w * 0.5f, h * 0.72f), end = Offset(w * 0.5f, h * 0.92f),
                strokeWidth = w * 0.07f, cap = StrokeCap.Round
            )
            drawLine(
                color = color, start = Offset(w * 0.35f, h * 0.93f), end = Offset(w * 0.65f, h * 0.93f),
                strokeWidth = w * 0.07f, cap = StrokeCap.Round
            )
        }
    }
}
