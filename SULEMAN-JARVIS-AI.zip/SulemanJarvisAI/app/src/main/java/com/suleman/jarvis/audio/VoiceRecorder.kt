package com.suleman.jarvis.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/** Records your own voice sample (AAC / .m4a) into the app's private storage. */
class VoiceRecorder(private val ctx: Context) {
    val file: File = File(ctx.filesDir, "my_voice_sample.m4a")
    private var rec: MediaRecorder? = null

    fun start() {
        val r = newRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(44100)
        r.setAudioEncodingBitRate(128000)
        r.setAudioChannels(1)
        r.setOutputFile(file.absolutePath)
        r.prepare()
        r.start()
        rec = r
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    /** Returns false if the recording was too short to be saved. */
    fun stop(): Boolean {
        val r = rec ?: return false
        rec = null
        return try {
            r.stop()
            true
        } catch (e: RuntimeException) {
            file.delete()
            false
        } finally {
            r.release()
        }
    }
}
