package com.suleman.jarvis.brain

import com.suleman.jarvis.data.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class AiException(val userMessage: String) : Exception(userMessage)

/**
 * Talks to a real AI service. Needs an API key from YOU (see README):
 *  - Google Gemini (has a free tier) or
 *  - Anthropic Claude (paid, pay-per-use)
 */
object AiClient {
    private const val GEMINI_MODEL = "gemini-2.5-flash"
    private const val CLAUDE_MODEL = "claude-haiku-5-5"

    suspend fun ask(s: AppSettings, history: List<Pair<String, String>>, user: String): String =
        withContext(Dispatchers.IO) {
            val system = systemPrompt(s)
            try {
                if (s.provider == "claude") askClaude(s, system, history, user)
                else askGemini(s, system, history, user)
            } catch (e: IOException) {
                throw AiException(s.t("No internet connection.", "इंटरनेट नहीं चल रहा है।"))
            }
        }

    private fun systemPrompt(s: AppSettings): String {
        val lang = if (s.hindi)
            "Reply in Hindi written in Devanagari script. Keep common English words (like YouTube, WiFi, app) in Latin letters."
        else "Reply in English."
        return "You are SULEMAN JARVIS AI, a personal voice assistant inspired by JARVIS from Iron Man, " +
            "running on the user's Android phone. Be polite, calm and helpful. Your answers are read aloud, " +
            "so keep them short (1 to 3 sentences), plain text only, no markdown, no emojis, no lists. " +
            "Do not claim you can do things on the phone that you cannot. $lang"
    }

    private fun askGemini(s: AppSettings, system: String, history: List<Pair<String, String>>, user: String): String {
        val key = s.geminiKey
        if (key.isBlank()) throw AiException(
            s.t("Please add your Gemini API key in Settings.", "कृपया सेटिंग्स में Gemini API key डालिए।")
        )
        fun item(role: String, text: String) = JSONObject().put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))
        val contents = JSONArray()
        for ((u, a) in history) {
            contents.put(item("user", u))
            contents.put(item("model", a))
        }
        contents.put(item("user", user))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put(
                "generationConfig", JSONObject()
                    .put("maxOutputTokens", 1024)
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            )
        val (code, text) = post(
            "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent",
            mapOf("x-goog-api-key" to key), body.toString()
        )
        if (code !in 200..299) fail(s, code)
        try {
            val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString().trim().ifEmpty { throw AiException(unexpected(s)) }
        } catch (e: AiException) {
            throw e
        } catch (e: Exception) {
            throw AiException(unexpected(s))
        }
    }

    private fun askClaude(s: AppSettings, system: String, history: List<Pair<String, String>>, user: String): String {
        val key = s.claudeKey
        if (key.isBlank()) throw AiException(
            s.t("Please add your Anthropic API key in Settings.", "कृपया सेटिंग्स में Anthropic API key डालिए।")
        )
        val msgs = JSONArray()
        for ((u, a) in history) {
            msgs.put(JSONObject().put("role", "user").put("content", u))
            msgs.put(JSONObject().put("role", "assistant").put("content", a))
        }
        msgs.put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", 400)
            .put("system", system)
            .put("messages", msgs)
        val (code, text) = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString()
        )
        if (code !in 200..299) fail(s, code)
        try {
            val arr = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
            return sb.toString().trim().ifEmpty { throw AiException(unexpected(s)) }
        } catch (e: AiException) {
            throw e
        } catch (e: Exception) {
            throw AiException(unexpected(s))
        }
    }

    private fun unexpected(s: AppSettings) =
        s.t("I got an unexpected reply from the AI service.", "AI सर्विस से अजीब जवाब मिला।")

    private fun fail(s: AppSettings, code: Int): Nothing = throw AiException(
        when (code) {
            400, 401, 403 -> s.t(
                "The AI service rejected the API key. Please check it in Settings.",
                "API key सही नहीं है। सेटिंग्स में जाँचिए।"
            )
            429 -> s.t(
                "Usage limit reached. Please try again later.",
                "लिमिट पूरी हो गई है। थोड़ी देर बाद कोशिश कीजिए।"
            )
            else -> s.t("The AI server had a problem ($code).", "AI सर्वर में दिक्कत है ($code)।")
        }
    )

    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            conn.disconnect()
        }
    }
}
