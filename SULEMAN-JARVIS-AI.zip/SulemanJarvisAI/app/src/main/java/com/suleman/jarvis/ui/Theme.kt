package com.suleman.jarvis.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val JBlue = Color(0xFF19B5FF)
val JRed = Color(0xFFFF2E4D)
val JAmber = Color(0xFFFFB300)
val JBg1 = Color(0xFF02050B)
val JBg2 = Color(0xFF0B1424)
val JPanel = Color(0xFF0E1726)
val JText = Color(0xFFD6ECFF)
val JMuted = Color(0xFF7F95AD)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = JBlue,
            secondary = JRed,
            background = JBg1,
            surface = JPanel,
            onPrimary = Color.Black,
            onBackground = JText,
            onSurface = JText
        ),
        content = content
    )
}
