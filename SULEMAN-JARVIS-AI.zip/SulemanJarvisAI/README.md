# SULEMAN JARVIS AI  (Kotlin + Jetpack Compose)

Native Android voice assistant. Android 8.0+ (built/targeted for Android 15–16, OPPO F29).

## HONEST STATUS
* This project was written by an AI in a sandbox with **no Android SDK**, so it was **not compiled or run here**.
  The first build might show a small error. If it does, send the error text/screenshot and it can be fixed quickly.
* No APK is included. You build it yourself (steps below, works from a phone only).

## What works
| Feature | Needs |
|---|---|
| Futuristic UI, animated AI circle, mic button | nothing |
| Hindi / Hinglish / English speech recognition (Google speech service on the phone) | Google app + internet (or offline pack) |
| Spoken replies (Android Text-to-Speech) | Google TTS engine; install Hindi voice data |
| "Open YouTube / Settings / any installed app", "time", "date", "search ..." | nothing (no API key) |
| General questions / chat | AI API key (below) |
| Voice cloning | ElevenLabs paid plan + key (below) |
| Background "Jarvis" wake word | foreground service + notification + your consent |

Example commands: "Jarvis open YouTube", "YouTube pe arijit singh ke gaane chalao", "settings kholo",
"time kya hua hai", "search weather in Delhi", "open WhatsApp", "व्हाट्सएप खोलो", "भारत की राजधानी क्या है".

## Accounts / money (all separate from this app)
* **Google Gemini API** – key from Google AI Studio. Has a free tier (limits/changes decided by Google). Default brain.
* **Anthropic Claude API** – separate account, pay-per-use credits. Optional.
* **ElevenLabs** – real voice cloning ("Instant Voice Cloning") needs a **paid plan**. Optional. Pricing/limits change – check their site.
* **GitHub** – free account; used only to compile the APK online.
Apps/time/date/search commands work with none of these.

Keys are typed in the app (Settings). They are encrypted with AES-256-GCM using a key kept in the Android Keystore.
They are never in the source code and are only sent to the service you chose.

## Voice cloning – what is real
* Normal replies use Android Text-to-Speech = an ordinary voice, **not** your voice.
* The app shows **"Phone text-to-speech (NOT cloned)"** or **"ElevenLabs CLONED voice"** so you always know.
* Cloning flow: tick consent (own voice only) → record ~2 min → upload to ElevenLabs → voice_id saved → replies use `eleven_multilingual_v2`.
* If ElevenLabs fails (no plan / no internet) the app says so and falls back to the normal voice.
* You can delete the cloned voice from inside the app.

## Android background-microphone rules (why the design is like this)
* Since Android 9–10, apps in the background cannot record audio; Android 14/15 also restrict starting microphone
  foreground services. The only permitted way is a **foreground service of type `microphone`** that shows a notification,
  started while the app is on screen, with RECORD_AUDIO (+ POST_NOTIFICATIONS on 13+).
* The app does exactly that, only after you accept a consent dialog, shows a permanent notification with a STOP button,
  never starts at boot, and reacts only to sentences containing "Jarvis".
* Background apps also cannot open other apps by themselves, so a command like "open YouTube" posts a **"Tap to continue" notification**.
* Oppo/ColorOS battery savers may kill it: Settings > Battery > App battery management > SULEMAN JARVIS AI > Allow background activity.
* While it is ON, the mic button inside the app is disabled (only one thing can use the mic).
* The system speech recognizer may make a small beep each cycle on some phones.

## BUILD THE APK FROM A PHONE ONLY (GitHub Actions – free)
1. Create a free account at github.com, open it in Chrome on the phone (menu → Desktop site is helpful).
2. New repository → name `jarvis` → Private → Create.
3. **Add file → Upload files** → pick `SULEMAN-JARVIS-AI.zip` (do not unzip it) → Commit.
4. **Add file → Create new file** → in the name box type exactly `.github/workflows/build.yml`
   → paste the text of `build-from-zip.yml` → Commit.
5. Open the **Actions** tab → "Build APK from ZIP" → wait ~5–10 min for a green tick.
   (If it did not start: click it → **Run workflow**.)
6. Open the finished run → bottom **Artifacts** → `SULEMAN-JARVIS-AI-apk` → downloads a ZIP.
7. Extract it with the Files app → `app-debug.apk`.
8. Tap the APK → allow "Install unknown apps" for your browser/Files app → Install.
   If Play Protect warns, choose "More details → Install anyway" (it is your own app, signed with a debug key).
9. Open the app → Allow microphone → Settings → paste an API key.

Red cross in Actions? Open the failed step, copy the red error lines, send them.

Alternative (PC/Android Studio): open the `SulemanJarvisAI` folder in Android Studio Ladybug+, let it sync, Build > Build APK(s).
Tools used: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, Compose BOM 2024.10.01, JDK 17, compileSdk 35.

## Hindi/Hinglish tips
* Settings → install Hindi speech: phone Settings → search "Google" → Speech → Offline recognition (optional).
* If Hindi replies are silent/English: Settings → search "Text-to-speech" → Google → install Hindi voice data.

## Project map
* `ui/` Compose screens, animated orb, ViewModel
* `audio/` SpeechListener, Speaker (TTS + ElevenLabs playback), VoiceRecorder
* `brain/` CommandProcessor (local commands), AiClient (Gemini/Claude), JarvisBrain
* `net/ElevenLabs.kt` voice clone + synthesis
* `data/` SecureStore (Keystore encryption), AppSettings
* `service/JarvisService.kt` microphone foreground service
