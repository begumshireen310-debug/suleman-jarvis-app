package com.jarvisx.app

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF151B27)
private val Cyan = Color(0xFF42E8F5)
private val Red = Color(0xFFFF435A)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisApp(
            speak = { speak(it) },
            launchSpeech = { callback -> startSpeech(callback) }
        ) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("hi", "IN")
            tts?.setPitch(0.82f)
            tts?.setSpeechRate(0.92f)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_x_utterance")
    }

    private fun startSpeech(callback: (String) -> Unit) {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS X को बोलें")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 72)
            pendingSpeech = callback
        } catch (_: Exception) {
            callback("Speech recognition service उपलब्ध नहीं है।")
        }
    }

    private var pendingSpeech: ((String) -> Unit)? = null
    @Deprecated("Android speech recognizer result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 72 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            pendingSpeech?.invoke(text)
        }
        pendingSpeech = null
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private enum class Module(val title: String, val subtitle: String) {
    HOME("JARVIS X", "आपका personal assistant"),
    CODING("Coding AI", "Code लिखें, समझें और debug करें"),
    YOUTUBE("YouTube AI", "वीडियो खोजें और content ideas"),
    QURAN("Quran AI", "Surah और Ayah खोजें"),
    PERSONAL("Personal AI", "सामान्य बातचीत और commands"),
    SETTINGS("Settings", "Voice और preferences")
}

@Composable
private fun JarvisApp(
    speak: (String) -> Unit,
    launchSpeech: ((String) -> Unit) -> Unit
) {
    var page by remember { mutableStateOf(Module.HOME) }
    var query by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var speechSpeed by remember { mutableFloatStateOf(0.92f) }
    var speechPitch by remember { mutableFloatStateOf(0.82f) }
    var assistantName by remember { mutableStateOf("JARVIS X") }
    var surahs by remember { mutableStateOf<List<Pair<Int, String>>>(emptyList()) }
    var selectedSurah by remember { mutableIntStateOf(0) }
    var ayahText by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan, secondary = Red,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101A29), Bg, Color(0xFF160C14))))
                .statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(assistantName, color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("PERSONAL AI SYSTEM", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Text("● ONLINE", color = Color(0xFF73F5A5), fontSize = 11.sp)
            }
            Spacer(Modifier.height(14.dp))
            if (page != Module.HOME) {
                Text("‹  Dashboard", color = Cyan, modifier = Modifier.clickable { page = Module.HOME }.padding(vertical = 8.dp))
            }
            when (page) {
                Module.HOME -> {
                    Box(Modifier.fillMaxWidth().weight(0.7f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(142.dp).background(
                                    Brush.radialGradient(listOf(Color(0xFF1C6977), Color(0xFF192B43), Color.Transparent)),
                                    RoundedCornerShape(100.dp)
                                ).clickable { speak("नमस्ते, मैं JARVIS X हूँ। बताइए, क्या करना है?") },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("JX", color = Cyan, fontSize = 44.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("TAP ORB TO SPEAK", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 2.sp)
                            Button(onClick = { launchSpeech { query = it; page = Module.PERSONAL } }) {
                                Text("🎙  Voice Command")
                            }
                        }
                    }
                    Text("YOUR TOOLS", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    listOf(Module.CODING, Module.YOUTUBE, Module.QURAN, Module.PERSONAL).forEach { m ->
                        ModuleCard(m) { page = m; result = ""; query = "" }
                        Spacer(Modifier.height(8.dp))
                    }
                    OutlinedButton(onClick = { page = Module.SETTINGS }, modifier = Modifier.fillMaxWidth()) { Text("⚙ Settings & Voice") }
                }
                Module.CODING -> {
                    Text("CODING AI", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("HTML • CSS • JavaScript • Python • Kotlin • Java", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Code या error यहाँ लिखें") }, minLines = 4)
                    Button(onClick = { result = "Coding AI backend अभी configure नहीं है। यह starter कोई नकली AI जवाब नहीं बनाएगा। अगला चरण: secure backend/API जोड़ना।" }, modifier = Modifier.fillMaxWidth()) { Text("Analyze / Explain") }
                    ResultPanel(result)
                }
                Module.YOUTUBE -> {
                    Text("YOUTUBE AI", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("क्या खोजना है?") })
                    Button(onClick = {
                        if (query.isNotBlank()) {
                            val uri = android.net.Uri.parse("https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(query, "UTF-8"))
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                result = "YouTube search browser/app में खोली गई।"
                            } catch (_: Exception) {
                                result = "YouTube search खोल नहीं पाए। कोई browser install/enable करके फिर कोशिश करें।"
                            }
                        } else result = "पहले search लिखें या voice button दबाएँ।"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Search in YouTube") }
                    Button(onClick = { launchSpeech { query = it } }, modifier = Modifier.fillMaxWidth()) { Text("🎙 बोलकर Search लिखें") }
                    Text("Title / description / tags ideas के लिए prompt लिखें:", color = Color.LightGray)
                    ResultPanel("यह starter वास्तविक YouTube API results या AI-generated metadata का दावा नहीं करता। Search खोलने के लिए ऊपर का बटन इस्तेमाल करें।")
                }
                Module.QURAN -> {
                    Text("QURAN AI", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Surah सूची reliable public Quran API से आती है।", color = Color.LightGray, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            loading = true
                            scope.launch {
                                val fetched = withContext(Dispatchers.IO) { fetchSurahs() }
                                surahs = fetched
                                result = if (fetched.isEmpty()) "Surah list नहीं मिली। Internet जाँचकर Retry करें।" else ""
                                loading = false
                            }
                        }, modifier = Modifier.weight(1f)) { Text(if (loading) "Loading…" else "Load Surah List") }
                        Button(onClick = {
                            if (selectedSurah in 1..114) {
                                loading = true
                                scope.launch {
                                    ayahText = withContext(Dispatchers.IO) { fetchSurahText(selectedSurah) }
                                    loading = false
                                }
                            } else result = "पहले सूची में से Surah चुनें।"
                        }, modifier = Modifier.weight(1f)) { Text("Open selected") }
                    }
                    if (surahs.isNotEmpty()) {
                        LazyColumn(Modifier.weight(1f)) {
                            items(surahs) { item ->
                                Row(Modifier.fillMaxWidth().clickable { selectedSurah = item.first }
                                    .background(if (selectedSurah == item.first) Color(0xFF203B4A) else Panel, RoundedCornerShape(8.dp))
                                    .padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${item.first}. ${item.second}", color = if (selectedSurah == item.first) Cyan else Color.White)
                                }
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }
                    if (ayahText.isNotBlank()) {
                        LazyColumn(Modifier.weight(1f)) { item { Text(ayahText, color = Color.White, lineHeight = 25.sp) } }
                    }
                    ResultPanel(result)
                }
                Module.PERSONAL -> {
                    Text("PERSONAL JARVIS", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("अपना सवाल या command लिखें") }, minLines = 2)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { launchSpeech { query = it } }, modifier = Modifier.weight(1f)) { Text("🎙 Voice") }
                        Button(onClick = {
                            val q = query.trim()
                            result = when {
                                q.contains("coding", true) -> { page = Module.CODING; "Coding AI खोला गया।" }
                                q.contains("youtube", true) -> { page = Module.YOUTUBE; "YouTube AI खोला गया।" }
                                q.contains("quran", true) || q.contains("surah", true) -> { page = Module.QURAN; "Quran AI खोला गया।" }
                                q.isBlank() -> "पहले सवाल लिखें या बोलें।"
                                else -> "Personal AI backend अभी configure नहीं है। वास्तविक AI उत्तर के लिए सुरक्षित backend/API जोड़ना बाकी है।"
                            }
                            speak(result)
                        }, modifier = Modifier.weight(1f)) { Text("Run command") }
                    }
                    ResultPanel(result)
                }
                Module.SETTINGS -> {
                    Text("SETTINGS", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(assistantName, { assistantName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Assistant name") })
                    Spacer(Modifier.height(16.dp))
                    Text("Speech speed: ${"%.2f".format(speechSpeed)}")
                    Slider(value = speechSpeed, onValueChange = { speechSpeed = it }, valueRange = 0.6f..1.3f)
                    Text("Voice pitch: ${"%.2f".format(speechPitch)}")
                    Slider(value = speechPitch, onValueChange = { speechPitch = it }, valueRange = 0.6f..1.3f)
                    Button(onClick = { speak("Voice preview. नमस्ते, मैं $assistantName हूँ।") }, modifier = Modifier.fillMaxWidth()) { Text("Preview voice") }
                    Text("ध्यान दें: इस starter में sliders preview से जुड़े UI controls हैं; system TTS पर लागू करने के लिए अगली code iteration चाहिए। आवाज़ और भाषा installed TTS engine पर निर्भर हैं।", color = Color.LightGray, fontSize = 12.sp)
                    Text("Background mic / wake word: शामिल नहीं है। App microphone को छिपकर नहीं चलाता।", color = Red, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ModuleCard(module: Module, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Color(0xFF202F43), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(when(module) { Module.CODING -> "</>"; Module.YOUTUBE -> "▶"; Module.QURAN -> "۞"; else -> "✦" }, color = Cyan, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(module.title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(module.subtitle, color = Color.LightGray, fontSize = 11.sp)
        }
        Text("›", color = Red, fontSize = 28.sp)
    }
}

@Composable
private fun ResultPanel(text: String) {
    if (text.isNotBlank()) {
        Spacer(Modifier.height(10.dp))
        Text(text, Modifier.fillMaxWidth().background(Color(0xFF101722), RoundedCornerShape(12.dp)).padding(12.dp), color = Color.White, fontSize = 13.sp)
    }
}

private fun fetchSurahs(): List<Pair<Int, String>> {
    return try {
        val conn = (URL("https://api.alquran.cloud/v1/surah").openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 10000; requestMethod = "GET"
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val data = JSONObject(body).getJSONArray("data")
        (0 until data.length()).map { i ->
            val obj = data.getJSONObject(i)
            obj.getInt("number") to obj.getString("englishName")
        }
    } catch (_: Exception) { emptyList() }
}

private fun fetchSurahText(number: Int): String {
    return try {
        val conn = (URL("https://api.alquran.cloud/v1/surah/$number/editions/quran-uthmani,en.asad").openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 12000; requestMethod = "GET"
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val editions = JSONObject(body).getJSONArray("data")
        val arabic = editions.getJSONObject(0).getJSONArray("ayahs")
        val english = editions.getJSONObject(1).getJSONArray("ayahs")
        buildString {
            for (i in 0 until minOf(arabic.length(), english.length())) {
                append("Ayah ${i + 1}\\n")
                append(arabic.getJSONObject(i).getString("text")).append("\\n")
                append(english.getJSONObject(i).getString("text")).append("\\n\\n")
            }
        }
    } catch (e: Exception) { "Quran API error: ${e.message ?: "network unavailable"}. Internet जाँचकर फिर कोशिश करें।" }
}

