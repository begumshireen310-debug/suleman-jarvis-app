# JARVIS X — Android project (पहला working starter)

यह **source project** है, APK नहीं। इस ZIP में Kotlin + Jetpack Compose का शुरुआती ऐप है:
- एक dashboard और चार module screens
- Android Speech Recognizer से बोलकर text भरना (फोन की उपलब्ध speech service पर निर्भर)
- Android TextToSpeech, भाषा/स्पीड/pitch controls
- YouTube खोज को YouTube app/browser में खोलना
- Quran module में AlQuran Cloud API से Surah सूची और आयतें लाना
- स्थानीय greeting/name/theme settings

## जरूरी सच्चाई
- यहाँ APK compile नहीं किया गया है; कोई APK इस ZIP में शामिल नहीं है।
- Coding AI और Personal AI के लिए वास्तविक AI जवाब पाने हेतु अपने backend/API integration की जरूरत है। इस starter में AI modules ईमानदारी से बतायेंगे कि backend configure करना बाकी है; यह नकली AI जवाब नहीं बनाता।
- Quran API के लिए इंटरनेट चाहिए। अनुवाद API की उपलब्धता और नेटवर्क पर निर्भर है।
- Background always-on microphone/wake word शामिल नहीं है। Android पर इसके लिए foreground service, persistent notification, स्पष्ट opt-in और डिवाइस पर testing जरूरी है। इस starter में background recording नहीं होती।
- Deep male voice फोन के installed TTS engine/voices पर निर्भर है; pitch slider आवाज़ को थोड़ा बदल सकता है, हर फोन पर असली deep male voice की गारंटी नहीं।

## फोन पर आगे क्या करना है
1. ZIP डाउनलोड करके किसी archive/file manager से extract करें।
2. Android पर AndroidIDE जैसे Kotlin/Gradle Android IDE में `JARVIS_X_Android_Project` folder खोलें। Gradle sync होने दें।
3. Build/Run करें। पहली build में इंटरनेट और काफी storage लग सकती है।
4. Build fail हो तो पूरा error message/screenshot भेजें; उसी के अनुसार अगला कदम होगा।

यह project Android Studio/Gradle के compatible environment के लिए है। मोबाइल IDE की Gradle/JDK compatibility अलग हो सकती है।
